package ast;

public class VarDefinition {
    private String name;
}
