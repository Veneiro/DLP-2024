package ast.expression;

import ast.ASTAbstractNode;

public class UnaryMinus extends ASTAbstractNode implements Expression {
    public Expression num;
}
