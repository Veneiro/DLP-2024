package ast.expression;

import ast.visitor.Visitor;

public abstract class AbstractExpression implements Expression {

    public boolean lvalue;

    public void setLValue(boolean v){
        this.lvalue = v;
    }

    public boolean getLValue(){
        return this.lvalue;
    }
}
