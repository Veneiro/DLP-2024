package ast.type;

import ast.ASTNode;

import java.util.List;

public interface Type extends ASTNode {
    Type arithmetic(Type type);

    Type castTo(Type type);

    Type comparison(Type type);

    Type squareBrackets(Type type);

    Type logical(Type type);

    Type modulus(Type type);

    Type unaryMinus();

    Type fieldAccess(Type type);

    Type parenthesis(List<Type> types);
}
