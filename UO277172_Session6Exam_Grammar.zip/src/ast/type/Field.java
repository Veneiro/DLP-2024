package ast.type;

public class Field {
    public Type fieldType;

    public Field(Type fieldType) {
        this.fieldType = fieldType;
    }
}
