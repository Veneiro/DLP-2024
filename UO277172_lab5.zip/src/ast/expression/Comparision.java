package ast.expression;

import ast.ASTAbstractNode;

public class Comparision extends ASTAbstractNode implements Expression {
    public String operator;
    public Expression firstCompare;
    public Expression secondCompare;
}
