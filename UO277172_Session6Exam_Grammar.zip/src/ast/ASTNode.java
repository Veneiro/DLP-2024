package ast;

public interface ASTNode {
    int getLine();
    int getColumn();
}
