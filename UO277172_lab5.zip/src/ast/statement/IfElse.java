package ast.statement;

import ast.ASTAbstractNode;
import ast.expression.Expression;

import java.util.ArrayList;

public class IfElse extends ASTAbstractNode implements Statement {
    public ArrayList<Statement> ifStat;
    public ArrayList<Statement> elseStat;
    public Expression expr;
}
