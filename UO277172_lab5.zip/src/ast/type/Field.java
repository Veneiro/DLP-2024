package ast.type;

public class Field {
    public Type fieldType;
}
