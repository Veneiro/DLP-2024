package ast.type;

import ast.ASTAbstractNode;

import java.util.ArrayList;

public class StrutType extends ASTAbstractNode implements Type {
    public ArrayList<Field> fields;
}
