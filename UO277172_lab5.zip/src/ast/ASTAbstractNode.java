package ast;

public abstract class ASTAbstractNode implements ASTNode {
    private int line;
    private int column;

    public int getLine(){
        return this.line;
    }

    public int getColumn(){
        return this.column;
    }

    public void setLine(int line){
        this.line = line;
    }

    public void setColumn(int column){
        this.column = column;
    }
}
