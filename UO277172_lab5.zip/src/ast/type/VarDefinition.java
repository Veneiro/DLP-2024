package ast.type;

public class VarDefinition {
    public Type type;
    public String name;
}
