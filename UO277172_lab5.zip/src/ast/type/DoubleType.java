package ast.type;

import ast.ASTAbstractNode;

public class DoubleType extends ASTAbstractNode implements Type {
}
