package ast.type;

import ast.ASTAbstractNode;

public class CharType extends ASTAbstractNode implements Type {
}
