package ast.program;

import ast.ASTAbstractNode;
import ast.statement.Statement;

import java.util.ArrayList;

public class VarDefinition extends ASTAbstractNode implements Definition {
    public ArrayList<Statement> statements;
    @Override
    public String getName() {
        return null;
    }
}
