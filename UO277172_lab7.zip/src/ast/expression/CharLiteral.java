package ast.expression;

import ast.ASTAbstractNode;
import ast.visitor.Visitor;

public class CharLiteral extends ASTAbstractNode implements Expression {
    private char value;

    public CharLiteral(int line, int column, char value) {
        super(line, column);
        this.value = value;
    }

    @Override
    public <TP, TR> TR accept(Visitor visitor, TP param) {
        return visitor.visit(this, param);
    }
}
