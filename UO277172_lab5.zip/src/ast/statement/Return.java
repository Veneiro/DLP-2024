package ast.statement;

import ast.ASTAbstractNode;
import ast.expression.Expression;

public class Return extends ASTAbstractNode implements Statement {
    public Expression retExpr;
}
