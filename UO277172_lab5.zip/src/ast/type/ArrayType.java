package ast.type;

import ast.ASTAbstractNode;

public class ArrayType extends ASTAbstractNode implements Type {
    private int size;
    private Type type;
}
