package ast.expression;

import ast.ASTAbstractNode;

public class FieldAccess extends ASTAbstractNode implements Expression {
    public String name;
    public Expression toAccess;
}
