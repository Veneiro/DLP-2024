package ast.type;

import ast.ASTAbstractNode;

import java.util.ArrayList;

public class FunctionType extends ASTAbstractNode implements Type {
    public ArrayList<VarDefinition> definitions;
    public Type returnType;
}
