package ast.statement;

import ast.ASTAbstractNode;
import ast.expression.Expression;

import java.util.ArrayList;

public class Write extends ASTAbstractNode implements Statement {
    public ArrayList<Expression> toWrite;
}
