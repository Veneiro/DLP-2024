package ast.program;

import ast.ASTAbstractNode;

import java.util.ArrayList;

public class Program extends ASTAbstractNode {
    public ArrayList<Definition> definitions;
}
