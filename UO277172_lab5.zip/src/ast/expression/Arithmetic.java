package ast.expression;

import ast.ASTAbstractNode;

public class Arithmetic extends ASTAbstractNode implements Expression {
    public String operator;
    public Expression firstExp;
    public Expression secondExp;
    public Arithmetic(int line, int column, Expression fS, String op, Expression sS){
        setLine(line);
        setColumn(column);
        this.firstExp = fS;
        this.secondExp = sS;
    }
}
