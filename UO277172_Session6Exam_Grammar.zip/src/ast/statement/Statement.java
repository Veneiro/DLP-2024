package ast.statement;

import ast.ASTNode;

public interface Statement extends ASTNode {
}
