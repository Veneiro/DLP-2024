package ast.visitor;

import ast.expression.*;
import ast.program.Definition;
import ast.program.FuncDefinition;
import ast.program.Program;
import ast.program.VarDefinition;
import ast.statement.*;

public class TypeCheckingVisitor implements Visitor {

    // EXPRESSIONS
    @Override
    public <TP, TR> TR visit(Arithmetic arithmetic, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(Cast cast, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(CharLiteral charLiteral, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(Comparision comparision, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(Variable variable, TP param) {
        //variable.setLValue(true);
        return null;
    }

    @Override
    public <TP, TR> TR visit(FuncDefinition funcDefinition, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(Indexing indexing, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(IntLiteral intLiteral, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(Logical logical, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(Modulus modulus, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(RealLiteral realLiteral, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(UnaryMinus unaryMinus, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(UnaryNot unaryNot, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(FieldAccess fieldAccess, TP param) {
        return null;
    }

    // PROGRAM

    @Override
    public <TP, TR> TR visit(FuncInvocation funcInvocation, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(Program program, TP param){
        for (Definition d: program.definitions) {
            d.accept(this, param);
        }
        return null;
    }

    @Override
    public <TP, TR> TR visit(VarDefinition varDefinition, TP param) {
        return null;
    }

    // STATEMENTS

    @Override
    public <TP, TR> TR visit(Assignment assignment, TP param) {
        assignment.assign_to.accept(this, param);
        return null;
    }

    @Override
    public <TP, TR> TR visit(FunctionInvocation functionInvocation, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(IfElse ifElse, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(Read read, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(Return ret, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(While whl, TP param) {
        return null;
    }

    @Override
    public <TP, TR> TR visit(Write write, TP param) {
        return null;
    }
}
