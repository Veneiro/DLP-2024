package ast.type;

import ast.ASTNode;

public interface Type extends ASTNode {
}
