package ast.expression;

import ast.ASTAbstractNode;

public class UnaryNot extends ASTAbstractNode implements Expression {
    public Expression expr;
}
