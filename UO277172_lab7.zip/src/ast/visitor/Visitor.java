package ast.visitor;

import ast.expression.*;
import ast.program.FuncDefinition;
import ast.program.Program;
import ast.program.VarDefinition;
import ast.statement.*;

public interface Visitor {

    // EXPRESSIONS
    public <TP,TR> TR visit(Arithmetic arithmetic, TP param);
    public <TP, TR> TR visit(Cast cast,TP param);
    public <TP, TR> TR visit(CharLiteral charLiteral,TP param);
    public <TP, TR> TR visit(Comparision comparision,TP param);
    public <TP,TR> TR visit(FieldAccess fieldAccess, TP param);
    public <TP, TR> TR visit(FuncInvocation funcInvocation,TP param);
    public <TP, TR> TR visit(Indexing indexing,TP param);
    public <TP, TR> TR visit(IntLiteral intLiteral,TP param);
    public <TP, TR> TR visit(Logical logical,TP param);
    public <TP, TR> TR visit(Modulus modulus,TP param);
    public <TP, TR> TR visit(RealLiteral realLiteral,TP param);
    public <TP, TR> TR visit(UnaryMinus unaryMinus,TP param);
    public <TP, TR> TR visit(UnaryNot unaryNot,TP param);
    public <TP, TR> TR visit(Variable variable, TP param);

    // DEFINITIONS
    public <TP, TR> TR visit(FuncDefinition funcDefinition, TP param);
    public <TP, TR> TR visit(Program program, TP param);
    public <TP, TR> TR visit(VarDefinition varDefinition, TP param);

    // STATEMENT
    public <TP, TR> TR visit(Assignment assignment, TP param);
    public <TP, TR> TR visit(FunctionInvocation functionInvocation, TP param);
    public <TP, TR> TR visit(IfElse ifElse, TP param);
    public <TP, TR> TR visit(Read read, TP param);
    public <TP, TR> TR visit(Return ret, TP param);
    public <TP, TR> TR visit(While whl,TP param);
    public <TP, TR> TR visit(Write write,TP param);
}
