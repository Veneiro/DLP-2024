package ast.visitor;

import ast.expression.*;
import ast.program.FuncDefinition;
import ast.program.VarDefinition;
import ast.semantic.SymbolTable;
import ast.statement.Statement;
import ast.type.ErrorType;

public class IdentificationVisitor<TP,TR> extends AbstractVisitor<TP,TR> {

    SymbolTable table = new SymbolTable();

    @Override
    public TR visit(VarDefinition varDefinition, TP param) {
        varDefinition.type.accept(this, null);
        /**if (varDefinition instanceof VarDefinition) {
            new ErrorType(
                    definitionToFind.getLine(),
                    definitionToFind.getColumn(),
                    "Repeated variable definition " + definition.getVar_name()
            );
        } else {
            new ErrorType(
                    definitionToFind.getLine(),
                    definitionToFind.getColumn(),
                    "Repeated function definition " + definition.getVar_name());
        }*/
        table.insert(varDefinition);
        return null;
    }
    @Override
    public TR visit(Variable variable, TP param) {
        return null;
    }

    @Override
    public TR visit(FuncDefinition funcDefinition, TP param){
        table.insert(funcDefinition);
        table.set();
        for (Statement s: funcDefinition.statements
             ) {
            s.accept(this, null);
        }
        table.reset();
        return null;
    }
}
