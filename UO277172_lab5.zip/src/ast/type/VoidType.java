package ast.type;

import ast.ASTAbstractNode;

public class VoidType extends ASTAbstractNode implements Type {
}
