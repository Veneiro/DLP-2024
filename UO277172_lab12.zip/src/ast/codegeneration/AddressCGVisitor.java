package ast.codegeneration;

import ast.visitor.AbstractVisitor;

public class AddressCGVisitor<TP, TR> extends AbstractVisitor<TP,TR> {

    /**
     * address[[Variable: expression -> ID]]=
     * if(expression.definition.scope == 0)
     *      <pusha> expression.definition.offset
     *  else
     *      <push bp>
     *      <pushi> expression.definition.offset
     *      <addi>
     */

    /**
     *  address[[Indexing: expression1 -> expression2 expression3
     *  address[[expression2]]
     *  value[[expression3]]
     *  <pushi > expression1.type.offset
     *  <muli>
     *  <addi>
     *
     *
     *
     *
     *  address[[FieldAccess: expression1 -> expression2 ID]]
     *  address[[expression2]]
     *  <pushi > expression1.type.offset
     *  <addi>
     */
}
