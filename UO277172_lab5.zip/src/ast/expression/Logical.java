package ast.expression;

import ast.ASTAbstractNode;

public class Logical extends ASTAbstractNode implements Expression {
    public String operator;
    public Expression firstExp;
    public Expression secondExp;
}
