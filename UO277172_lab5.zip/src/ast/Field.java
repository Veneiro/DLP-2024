package ast;

public class Field {
    private String name;
}
