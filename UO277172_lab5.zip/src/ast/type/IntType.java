package ast.type;

import ast.ASTAbstractNode;

public class IntType extends ASTAbstractNode implements Type {
}
