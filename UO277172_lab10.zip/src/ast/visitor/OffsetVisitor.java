package ast.visitor;

import ast.expression.FieldAccess;
import ast.expression.Variable;

public class OffsetVisitor<TP,TR> extends AbstractVisitor<TP,TR>{

    /**
     * &global = SUMATORIO( noB(type(prev globals not including itself)))
     *
     * &param = BP + 4 + SUMATORIO( noB(type(params on the right not inlcuding itself)))
     *
     * (P) VariableDefinition: definition -> type ID*
     * (R) if(definition.getScope() == 0){
     *      for(String id : ID*)
     *          definition.offset -> definition.type.numberOfBytes(id)
     * } else {
     *
     * }
     */

    /**
     * &field = SUMATORIO( noB(types(prev fields not including itself)))
     * (P) field: field -> type ID
     * (R) field.offset -> field.type.numberOfBytes(ID)
     */

    /**
     * &local = BP - SUMATORIO( noB(type(prev locals including itself)))
     * (P) FunctionDefintion
     */
}
